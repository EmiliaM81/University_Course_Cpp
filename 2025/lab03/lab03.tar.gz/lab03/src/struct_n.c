

#include "../include/struct_n.h"
#include <stdio.h>


void print_structN(StructN* s) {
    printf("StructN: value=%d\n", s->valueN);
}
