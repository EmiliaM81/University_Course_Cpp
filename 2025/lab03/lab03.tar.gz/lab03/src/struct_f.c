
#include "../include/struct_f.h"
#include <stdio.h>


void print_structF(StructF* s) {
    printf("StructF: value=%d\n", s->valueF);
}
