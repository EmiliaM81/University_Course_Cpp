
#include "../include/struct_e.h"
#include <stdio.h>


void print_structE(StructE* s) {
    printf("StructE: value=%d\n", s->valueE);
}
