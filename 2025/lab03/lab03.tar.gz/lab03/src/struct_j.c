
#include "../include/struct_j.h"
#include <stdio.h>


void print_structJ(StructJ* s) {
    printf("StructJ: value=%d\n", s->valueJ);
}
