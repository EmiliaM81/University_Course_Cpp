
#include "../include/struct_i.h"
#include <stdio.h>


void print_structI(StructI* s) {
    printf("StructI: value=%d\n", s->valueI);
}
