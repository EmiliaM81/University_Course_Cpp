
#include <stdio.h>

#include "../include/struct_l.h"

void print_structL(StructL* s) {
    printf("StructL: value=%d\n", s->valueL);
}
