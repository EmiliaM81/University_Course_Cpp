#!/bin/bash

cd bin

./compil1
./compil2
./compil3

cd ../
