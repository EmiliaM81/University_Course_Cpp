#ifndef LIB_H
#define LIB_H

void fun3();
void fun2();

#endif
